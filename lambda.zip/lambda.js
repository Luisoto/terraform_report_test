const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = async (event, context, callback) => {
    switch (event.httpMethod) {
        case 'POST':
            const requestId = context.awsRequestId;
            const body = JSON.parse(event.body)
            
            await createItem(requestId, body).then(() => {
                callback(null, {
                    statusCode: 201,
                    body: '',
                    headers: {
                        'Access-Control-Allow-Origin' : '*'
                    }
                });
            }).catch((err) => {
                callback(null, {
                    statusCode: 500,
                    body: JSON.stringify(err),
                    headers: {
                        'Access-Control-Allow-Origin' : '*'
                    }
                });
            })
            break;
        case 'PUT':
            
            break;
        case 'GET':
            
            break;
        case 'DELETE':
            
            break;
        default:
            callback(null, {
                statusCode: 404,
                body: JSON.stringify('httpMethod not supported'),
                headers: {
                    'Access-Control-Allow-Origin' : '*'
                }
            });
            // code
    }

};

// Function createMessage
// Writes message to DynamoDb table Message 
function createItem(requestId, body) {
    
    const params = {
        TableName: 'ItemsTable',
        Item: {
            'id' : requestId,
            'date': new Date(),
            'message' : body.message
        }
    }
    return ddb.put(params).promise();
}